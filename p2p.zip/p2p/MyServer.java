import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;

public class MyServer extends Thread{
    private ServerSocket serverSocket;
    private static int serverPort=6065;
    private static int clientPorts=6090;
    public MyServer() throws IOException
    {
        serverSocket = new ServerSocket(serverPort);
        serverSocket.setSoTimeout(500000);
    }
    public void run()
    {

        while(true)
        {
            try
            {
                System.out.println("Waiting for client on port " + serverSocket.getLocalPort() + "...");
                Socket server = serverSocket.accept();
                DataInputStream in = new DataInputStream(server.getInputStream());
                String inp = in.readUTF();
                //1 for register
                if(inp.charAt(0)=='1'){
                    String[] inps = inp.split("[,]",3);
                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("users.txt")));
                    String ln;
                    int res=1,id=1;
                    while ((ln=br.readLine())!=null){
                        id++;
                        if( inps[1].equals( ln.split("[ ]",3)[1] ) ){
                            res=2;
                            break;
                        }
                    }
                    br.close();
                    if(res==1){
                        Writer bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("users.txt", true), "UTF-8"));
                        bw.append(id+" "+inps[1]+" 0 ip port "+inps[2]+"\n");
                        bw.close();
                    }
                    DataOutputStream out = new DataOutputStream(server.getOutputStream());
                    out.writeInt(res);
                }
                //2 for login
                else if (inp.charAt(0)=='2'){
                    String[] inps = inp.split("[,]",3);
                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("users.txt")));
                    String ln;
                    StringBuilder wholefile = new StringBuilder();
                    int res=2,id=1;
                    while ((ln=br.readLine())!=null){
                        if( inps[1].equals( ln.split("[ ]",6)[1] ) ){
                            if(inps[2].equals( ln.split("[ ]",6)[5] ) && ( ln.split("[ ]",4)[2].charAt(0)=='0' ) ){
                                res=1;
                                String ip = server.getRemoteSocketAddress().toString().split("[:]")[0];
                                ln=ln.replaceFirst("0 ip ","1 "+ip.substring(1)+" " );
                                ln=ln.replaceFirst(" port "," "+(clientPorts++)+" ");
                                wholefile.append(ln);
                                wholefile.append('\n');
                            }
                            else{
                                wholefile.append(ln);
                                wholefile.append('\n');
                            }
                        }
                        else {
                            wholefile.append(ln);
                            wholefile.append('\n');
                        }
                        if(res==2){id++;}
                    }
                    br.close();
                    if(res==1){
                        PrintWriter w = new PrintWriter("users.txt","UTF-8");
                        w.print(wholefile);
                        w.close();
                    }
                    DataOutputStream out = new DataOutputStream(server.getOutputStream());
                    out.writeUTF(res+" "+id+" "+(clientPorts-1));
                }
                //3 for logout
                else if (inp.charAt(0)=='3'){
                    int id = Integer.parseInt(inp.substring(2));
                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("users.txt")));
                    String ln;
                    StringBuilder wholefile = new StringBuilder();
                    int res=2;
                    while ((ln=br.readLine())!=null) {
                        if (ln.startsWith(id + "")) {
                            String[] fields = ln.split("[ ]", 6);
                            if (server.getRemoteSocketAddress().toString().contains(fields[3])) {
                                res = 1;
                                wholefile.append(fields[0]+" "+fields[1]+" 0 ip port "+fields[5]+"\n");
                            }
                            else {
                                wholefile.append(ln);
                                wholefile.append('\n');
                            }
                        }
                        else {
                            wholefile.append(ln);
                            wholefile.append('\n');
                        }
                    }
                    br.close();
                    if(res==1){
                        PrintWriter w = new PrintWriter("users.txt","UTF-8");
                        w.print(wholefile);
                        w.close();
                    }
                }
                //4 for addfriend
                else if(inp.charAt(0)=='4'){
                    String[] inps = inp.split("[,]",3);
                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("users.txt")));
                    String ln,ip="-";
                    int fid=0;
                    while ((ln=br.readLine())!=null){
                        if(ln.startsWith(inps[1]+" ")){
                            ip = ln.split("[ ]",6)[3];
                        }
                        else if( inps[2].equals( ln.split("[ ]",6)[1] ) ) {
                            fid = Integer.parseInt( ln.split("[ ]",6)[0] );
                        }
                    }
                    br.close();
                    if(server.getRemoteSocketAddress().toString().contains(ip) && fid!=0){
                        int uid=Integer.parseInt(inps[1]);
                        if(fid<uid){
                            int k = fid;
                            fid = uid;
                            uid = k;
                        }
                        int res=1;
                        br = new BufferedReader(new InputStreamReader(new FileInputStream("friends.txt")));
                        while ( (ln=br.readLine())!=null ){
                            if(ln.equals(uid+" "+fid)){
                                res=2;
                                break;
                            }
                        }
                        br.close();
                        if(res==1){
                            Writer bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("friends.txt", true), "UTF-8"));
                            bw.append(uid+" "+fid+"\n");
                            bw.close();
                        }
                        DataOutputStream out = new DataOutputStream(server.getOutputStream());
                        out.writeInt(res);
                    }
                    else {
                        DataOutputStream out = new DataOutputStream(server.getOutputStream());
                        out.writeInt(3);
                    }
                }
                //5 for getfriendlist
                else if(inp.charAt(0)=='5'){
                    int uid = Integer.parseInt(inp.substring(2));
                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("friends.txt")));
                    String ln;
                    int i,j;
                    ArrayList<Integer> fids = new ArrayList<Integer>();
                    while ( (ln=br.readLine())!=null ){
                        i=Integer.parseInt(ln.split("[ ]")[0]);
                        j=Integer.parseInt(ln.split("[ ]")[1]);
                        if(uid==i){
                            fids.add(j);
                        }
                        else if(uid==j){
                            fids.add(i);
                        }
                    }
                    br.close();
                    if(fids.size()>0){
                        ArrayList<String> fname = new ArrayList<String>();
                        Collections.sort(fids);
                        i=0;
                        br = new BufferedReader(new InputStreamReader(new FileInputStream("users.txt")));
                        while ( (ln=br.readLine())!=null && i<fids.size()){
                            if(ln.startsWith(fids.get(i)+" ")){
                                fname.add( ln.split("[ ]",3)[1] );
                                i++;
                            }
                        }
                        br.close();
                        StringBuilder res = new StringBuilder();
                        res.append(fids.get(0)+","+fname.get(0));
                        for(i=1;i<fids.size();i++){
                            res.append(" "+fids.get(i)+","+fname.get(i));
                        }
                        DataOutputStream out = new DataOutputStream(server.getOutputStream());
                        out.writeUTF(res.toString());
                    }
                    else{
                        DataOutputStream out = new DataOutputStream(server.getOutputStream());
                        out.writeUTF("");
                    }
                }
                //6 for get ip port of friend
                else if(inp.charAt(0)=='6'){
                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("users.txt")));
                    String ln,res="";
                    while ( (ln=br.readLine())!=null ){
                        if(ln.startsWith(inp.substring(2)+" ")){
                            res=ln.split("[ ]",6)[3]+" "+ln.split("[ ]",6)[4];
                            break;
                        }
                    }
                    br.close();
                    DataOutputStream out = new DataOutputStream(server.getOutputStream());
                    out.writeUTF(res);
                }
                server.close();
            }catch(SocketTimeoutException s)
            {
                System.out.println("Socket timed out!");
                break;
            }catch(IOException e)
            {
                e.printStackTrace();
                break;
            }
        }
    }
    public static void main(String [] args)
    {
        try
        {
            Thread t = new MyServer();
            t.start();
        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
