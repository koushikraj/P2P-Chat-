import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

class Friend{
    int id;
    String name;
    ArrayList<String> msg;
    boolean isnew;
    Friend(int id,String name){
        this.id=id;
        this.name=name;
        isnew=false;
        msg=new ArrayList<String>();
    }
}
public class ChatApp {
    private JFrame mainFrame;
    private JPanel loginPage,registerPage,homePage,addFriendPage,chatPage;
    private JLabel msgLabel;
    private JTextField username;
    private JPasswordField userpass,passconfirm;
    private JButton login,register,back;
    private boolean isloggedin;
    private int usrId;
    private String usrName;
    private int usrPort;
    private ArrayList<Friend> myFriends;
    private int page;
    private Thread t;
    private static String serverName = "127.0.0.1";	/**** Change ip address of server before running ****/
    private static int serverPort = 6065;
    private static String fName ;
    private static int fPort ;
    private static int y;
    private static boolean isfirst=true;
    public ChatApp(){
        isloggedin=false;
        myFriends = new ArrayList<Friend>();
        mainFrame = new JFrame();
        mainFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                logoutUser();
                System.exit(0);
            }
        });
        loginPage=new JPanel();
        mainFrame.setContentPane(loginPage);
        mainFrame.setSize(400,400);
        //initLoginPage();
        //initRegisterPage();
        //initHomePage();
        //initChatPage();
        //mainFrame.setLocationByPlatform(true);
        setLoginPage();
    }
    public static void main(String[] args){
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                ChatApp chatApp = new ChatApp();
            }
        });
    }
    protected void setLoginPage(){
        page=-1;
        loginPage = (JPanel)mainFrame.getContentPane();
        loginPage.removeAll();
        initLoginPage();
        loginPage.revalidate();
        loginPage.repaint();
        mainFrame.setTitle("ChatApp-Login");
       
        mainFrame.setVisible(true);
    }
    protected void setRegisterPage(){
        page=-1;
        registerPage = (JPanel) mainFrame.getContentPane();
        registerPage.removeAll();
        initRegisterPage();
        registerPage.revalidate();
        registerPage.repaint();
        mainFrame.setTitle("ChatApp-Register");
    }
    protected void setHomePage(){
        page=0;
        homePage = (JPanel) mainFrame.getContentPane();
        homePage.removeAll();
        initHomePage();
        homePage.revalidate();
        homePage.repaint();
        mainFrame.setTitle("ChatApp-Welcome "+usrName);
    }
    protected void setAddFriendPage(){
        page=-1;
        addFriendPage = (JPanel) mainFrame.getContentPane();
        addFriendPage.removeAll();
        initAddFriendPage();
        addFriendPage.revalidate();
        addFriendPage.repaint();
        mainFrame.setTitle("ChatApp-Add Friend");
    }
    protected void setChatPage(int id){
        try
        {
            Socket client = new Socket(serverName, serverPort);
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);
            out.writeUTF("6,"+id);
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);
            String msg = in.readUTF();
            if(msg.startsWith("ip")){
                JOptionPane.showMessageDialog(null, "Not Logged In");
                setHomePage();
                client.close();
                return;
            }
            else{
                fName = msg.split("[ ]")[0];	//conecting to fnd 
                fPort = Integer.parseInt(msg.split("[ ]")[1]);
            }
            client.close();
        }
        catch(IOException ee)
        {
            ee.printStackTrace();
        }
        page=id;
        chatPage = (JPanel) mainFrame.getContentPane();
        chatPage.removeAll();
        initChatPage(id);
        chatPage.revalidate();
        chatPage.repaint();
        mainFrame.setTitle("ChatApp-"+usrName+" with "+ myFriends.get(getIndex(id,0,myFriends.size()-1)).name );
    }
    protected void initLoginPage(){
        //loginPage.setOpaque(true);
        //loginPage.setBackground(Color.WHITE);
        loginPage.setLayout(null);
        msgLabel = new JLabel("Welcome Enter username,password");
        msgLabel.setSize(300, 30);
        msgLabel.setLocation(50, 5);
        username=new JTextField();
        username.setSize(300,30);
        username.setLocation(50,50);
        userpass=new JPasswordField();
        userpass.setSize(300,30);
        userpass.setLocation(50,100);
        login = new JButton("Login");
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {	//gui for button
                String usr = username.getText();
                char[] pass = userpass.getPassword();
                String usrpass = userpass.getText();
                if(usr.length()==0){
                    msgLabel.setText("Enter Username");
                    return;
                }
                else if(pass.length==0){
                    msgLabel.setText("Enter password");
                    return;
                }
                int i;
                for(i=0;i<usr.length();i++){
                    if( (usr.charAt(i)>='a' && usr.charAt(i)<='z') || (usr.charAt(i)>='A' && usr.charAt(i)<='Z') ){}
                    else {
                        msgLabel.setText("check username");
                        return;
                    }
                }
                try
                {
                    Socket client = new Socket(serverName, serverPort);
                    OutputStream outToServer = client.getOutputStream();
                    DataOutputStream out = new DataOutputStream(outToServer);
                    out.writeUTF("2,"+usr+","+usrpass);
                    InputStream inFromServer = client.getInputStream();
                    DataInputStream in = new DataInputStream(inFromServer);
                    String msg = in.readUTF();
                    if(msg.charAt(0)=='1'){
                        isloggedin=true;
                        usrName=usr;
                        String[] fields = msg.split(" ");
                        usrPort = Integer.parseInt(fields[2]);
                        usrId = Integer.parseInt(fields[1]);
                        setHomePage();
                    }
                    else if(msg.charAt(0)=='2'){
                        username.setText("");
                        userpass.setText("");
                        msgLabel.setText("Incorrect username or password");
                    }
                    else {
                        msgLabel.setText("Some error occurred");
                    }
                    client.close();
                }catch(IOException ee)
                {
                    ee.printStackTrace();
                    msgLabel.setText("Some error occurred");
                }
            }
        });
        login.setSize(100, 30);
        login.setLocation(150, 150);
        register = new JButton("Register");
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setRegisterPage();
            }
        });
        register.setSize(100, 30);
        register.setLocation(150, 200);
        back = new JButton("Exit");
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
            }
        });
        back.setSize(100, 30);
        back.setLocation(150, 300);

        loginPage.add(msgLabel);
        loginPage.add(username);
        loginPage.add(userpass);
        loginPage.add(login);
        loginPage.add(register);
        loginPage.add(back);
    }
    protected void initRegisterPage(){
        registerPage.setLayout(null);
        back = new JButton("Back");
        back.setSize(100, 30);
        back.setLocation(0, 0);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setLoginPage();
            }
        });
        msgLabel = new JLabel("Enter username,password,confirm");
        msgLabel.setSize(300, 30);
        msgLabel.setLocation(50, 50);
        username=new JTextField();
        username.setSize(300,30);
        username.setLocation(50,100);
        userpass=new JPasswordField();
        userpass.setSize(300,30);
        userpass.setLocation(50,150);
        passconfirm=new JPasswordField();
        passconfirm.setSize(300,30);
        passconfirm.setLocation(50,200);
        register = new JButton("Register");
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usr = username.getText();
                char[] pass1 = userpass.getPassword();
                char[] pass2 = passconfirm.getPassword();
                if(usr.length()==0 || pass1.length==0 || pass2.length==0 ){
                    msgLabel.setText("Enter all fields");
                    return;
                }
                int i;
                for(i=0;i<usr.length();i++){
                    if( (usr.charAt(i)>='a' && usr.charAt(i)<='z') || (usr.charAt(i)>='A' && usr.charAt(i)<='Z') ){

                    }
                    else {
                        msgLabel.setText("Username contains only alphabets");
                        return;
                    }
                }
                if(pass1.length==pass2.length){
                    StringBuilder usrpass = new StringBuilder();
                    for(i=0;i<pass1.length;i++){
                        usrpass.append(pass1[i]);
                        if(pass1[i]!=pass2[i]){
                            break;
                        }
                    }
                    if(i==pass1.length){
                        try
                        {
                            Socket client = new Socket(serverName, serverPort);
                            OutputStream outToServer = client.getOutputStream();	//app
                            DataOutputStream out = new DataOutputStream(outToServer);
                            out.writeUTF("1,"+usr+","+usrpass);
                            InputStream inFromServer = client.getInputStream();
                            DataInputStream in = new DataInputStream(inFromServer);
                            int msg = in.readInt();
                            if(msg==1){
                                username.setText("");
                                userpass.setText("");
                                passconfirm.setText("");
                                msgLabel.setText("Successfully registered");
                            }
                            else if(msg==2){
                                username.setText("");
                                userpass.setText("");
                                passconfirm.setText("");
                                msgLabel.setText("Username Already exists");
                            }
                            else {
                                msgLabel.setText("Some error occurred");
                            }
                            client.close();
                        }catch(IOException ee)
                        {
                            ee.printStackTrace();
                            msgLabel.setText("Some error occurred");
                        }
                        return;
                    }
                }
                msgLabel.setText("Both password should be same");

            }
        });
        register.setSize(100, 30);
        register.setLocation(150, 250);

        registerPage.add(msgLabel);
        registerPage.add(username);
        registerPage.add(userpass);
        registerPage.add(passconfirm);
        registerPage.add(register);
        registerPage.add(back);
    }
    protected void initHomePage(){
        homePage.setLayout(null);
        back = new JButton("Logout");
        back.setSize(100, 30);
        back.setLocation(250, 0);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logoutUser();
                setLoginPage();
            }
        });
        register = new JButton("Add Friend");
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setAddFriendPage();
            }
        });
        register.setSize(120, 30);
        register.setLocation(40, 0);

        homePage.add(register);
        homePage.add(back);

        String friends="";
        try
        {
            Socket client = new Socket(serverName, serverPort);
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);
            out.writeUTF("5,"+usrId);
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);
            friends = in.readUTF();
            client.close();
        }catch(IOException ee)
        {
            ee.printStackTrace();
        }
        if(friends.length()==0){
            msgLabel = new JLabel("No friends for you");
            msgLabel.setSize(300, 30);
            msgLabel.setLocation(50, 50);
            homePage.add(msgLabel);
        }
        else {
            String[] friend = friends.split("[ ]");
            int i,j=0;
            boolean isnull=false;
            for(i=0;i<friend.length;i++){
                login = new JButton(friend[i].split("[,]")[1]);
                login.setActionCommand(friend[i].split("[,]")[0]);
                login.setOpaque(true);
                login.setBackground(Color.BLUE);
                if(j<myFriends.size()){//parsing input message data
                    if(myFriends.get(j).id!=Integer.parseInt(login.getActionCommand())){
                        myFriends.add(j,new Friend( Integer.parseInt(login.getActionCommand()),login.getText() ));
                    }
                    else{
                        if(myFriends.get(j).isnew){
                            login.setText(login.getText()+"-new message(s) came");
                            login.setBackground(Color.CYAN);
                        }
                    }
                }
                else{
                    myFriends.add(new Friend( Integer.parseInt(login.getActionCommand()),login.getText() ));
                }
                j++;
                login.setSize(400, 30);
                login.setLocation(0, 50*i+50);
                login.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChatPage(Integer.parseInt(e.getActionCommand()));
                    }
                });
                homePage.add(login);
            }
        }
        if(isfirst){
            isfirst=false;
            try {
                t = new MyThread();//online lo unada leda 
            } catch (IOException e) {
                e.printStackTrace();
            }
            t.start();
        }
        else if(!t.isAlive()){
            try {
                t = new MyThread();
            } catch (IOException e) {
                e.printStackTrace();
            }
            t.start();
        }
    }
    protected void initAddFriendPage(){
        addFriendPage.setLayout(null);
        back = new JButton("Back");
        back.setSize(100, 30);
        back.setLocation(0, 0);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setHomePage();
            }
        });
        msgLabel = new JLabel("Enter username of your friend");
        msgLabel.setSize(300, 30);
        msgLabel.setLocation(50, 50);
        username=new JTextField();
        username.setSize(300,30);
        username.setLocation(50,100);
        register = new JButton("Add Friend");
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usr = username.getText();
                if(usr.length()==0){
                    msgLabel.setText("Enter Username");
                    return;
                }
                for(int i=0;i<usr.length();i++){
                    if( !(usr.charAt(i)>='a' && usr.charAt(i)<='z' )  ){
                        msgLabel.setText("Not valid");
                        return;
                    }
                }
                try
                {
                    Socket client = new Socket(serverName, serverPort);
                    OutputStream outToServer = client.getOutputStream();
                    DataOutputStream out = new DataOutputStream(outToServer);
                    out.writeUTF("4,"+usrId+","+usr);
                    InputStream inFromServer = client.getInputStream();
                    DataInputStream in = new DataInputStream(inFromServer);
                    int msg = in.readInt();
                    if(msg==1){
                        msgLabel.setText("Friend added successfully");
                    }
                    else if(msg==2){
                        msgLabel.setText("Already your friend");
                    }
                    else if(msg==3){
                        msgLabel.setText("Not valid");
                    }
                    else{
                        msgLabel.setText("Some error occurred");
                    }
                    client.close();
                }
                catch(IOException ee)
                {
                    ee.printStackTrace();
                    msgLabel.setText("Some error occurred");
                }
            }
        });
        register.setSize(120, 30);
        register.setLocation(140, 150);

        addFriendPage.add(register);
        addFriendPage.add(back);
        addFriendPage.add(msgLabel);
        addFriendPage.add(username);
    }
    protected void initChatPage(int id){
        y=100;
        final int indx = getIndex(id,0,myFriends.size()-1);
        myFriends.get(indx).isnew=false;
        chatPage.setLayout(null);
        back = new JButton("Back");
        back.setSize(100, 30);
        back.setLocation(0, 0);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setHomePage();
            }
        });
        username=new JTextField();
        username.setSize(300,30);
        username.setLocation(0,50);
        register = new JButton("Send");
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usr = username.getText();
                if(usr.length()==0){
                    return;
                }
                username.setText("");
                try
                {
                    Socket client = new Socket(fName, fPort);
                    OutputStream outToServer = client.getOutputStream();
                    DataOutputStream out = new DataOutputStream(outToServer);
                    out.writeUTF(usrId+","+usr);
                    msgLabel = new JLabel(usr);
                    msgLabel.setSize(300, 30);
                    msgLabel.setLocation(200, y);y+=50;
                    chatPage.add(msgLabel);
                    chatPage.revalidate();
                    chatPage.repaint();
                    myFriends.get(indx).msg.add("m"+usr);
                    client.close();
                }
                catch(IOException ee)
                {
                    ee.printStackTrace();
                }
            }
        });
        register.setSize(100, 30);
        register.setLocation(300, 50);
        Friend f = myFriends.get(indx);
        for(int i=0;i<f.msg.size();i++){
            String s = f.msg.get(i);
            if(s.charAt(0)=='m'){
                msgLabel = new JLabel(s.substring(1));
                msgLabel.setSize(300, 30);
                msgLabel.setLocation(200, y);y+=50;
                chatPage.add(msgLabel);
            }
            else {
                msgLabel = new JLabel(s.substring(1));
                msgLabel.setSize(300, 30);
                msgLabel.setLocation(0, y);y+=50;
                chatPage.add(msgLabel);
            }
        }

        chatPage.add(register);
        chatPage.add(back);
        chatPage.add(username);
    }
    private void logoutUser()  {
        isfirst=true;
        myFriends.clear();
        try {
            ((MyThread)t).close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(isloggedin){
            isloggedin=false;
            try
            {
                Socket client = new Socket(serverName, serverPort);
                OutputStream outToServer = client.getOutputStream();
                DataOutputStream out = new DataOutputStream(outToServer);
                out.writeUTF("3,"+usrId);
                client.close();
            }catch(IOException ee)
            {
                ee.printStackTrace();
            }
        }
    }
    private int getIndex(int id,int i,int j){
        if(i>j){
            return -1;
        }
        else if(i==j){
            if(id==myFriends.get(i).id){
                return i;
            }
            else {
                return -1;
            }
        }
        else {
            if(id>myFriends.get( (i+j)/2 ).id ){
                return getIndex(id,(i+j)/2+1,j);
            }
            else{
                return getIndex(id,i,(i+j)/2);
            }
        }
    }
    class MyThread extends Thread{
        ServerSocket serverSocket;
        Socket server=null;
        MyThread() throws IOException {
            serverSocket = new ServerSocket(usrPort);
            serverSocket.setSoTimeout(500000);
        }
        @Override
        public void run() {
            while (true){
                try{
                    server = serverSocket.accept();
                    DataInputStream in = new DataInputStream(server.getInputStream());
                    String inp = in.readUTF();
                    String[] inps = inp.split("[,]",2);
                    int fid = Integer.parseInt(inps[0]);
                    int indx = getIndex(fid,0,myFriends.size()-1);
                    if(fid==page){
                        msgLabel = new JLabel(inps[1]);
                        msgLabel.setSize(300, 30);
                        msgLabel.setLocation(0, y);y+=50;
                        chatPage.add(msgLabel);
                        chatPage.revalidate();
                        chatPage.repaint();
                        myFriends.get(indx).msg.add("f"+inps[1]);
                    }
                    else if(page==0){
                        setHomePage();
                        if(indx==-1){
                            indx = getIndex(fid,0,myFriends.size()-1);
                        }
                        myFriends.get(indx).msg.add("f"+inps[1]);
                        setChatPage(fid);
                    }
                    else{
                        if(indx>=0){
                            myFriends.get(indx).msg.add("f"+inps[1]);
                            myFriends.get(indx).isnew=true;
                        }
                    }
                    server.close();
                }
                catch(SocketTimeoutException s)
                {
                    System.out.println("Socket timed out!");
                    break;
                }
                catch(IOException e)
                {
                    e.printStackTrace();
                    break;
                }
            }
        }
        public void close() throws IOException {
            serverSocket.close();
            if(server!=null){
                server.shutdownInput();
                server.shutdownOutput();
                server.close();
            }
        }
    }
}
